# Berry's Fast Food Website

## Student Information

**Student Number:** ST10516188

**Project:** DISD1 Berry's Fast Food Website

**Assessment:** Part 2 - CSS Styling and Responsive Design

---

## 1. Project Description

Berry's Fast Food is a responsive website developed to
provide customers with information about the business,
its menu, locations, gallery and contact details.

The website was originally developed for Part 1 and has
now been improved for Part 2 by implementing CSS styling
and responsive design.

---

## 2. Website Pages

The website contains the following pages:

- Home
- About Us
- Menu
- Gallery
- Contact

---

## 3. Technologies Used

The website was developed using:

- HTML5
- CSS3
- CSS Grid
- Flexbox
- Media Queries
- Responsive Images
- Relative CSS Units
- GitHub

---

# 4. Part 1 Feedback and Corrections

Following the feedback received for Part 1, several
changes were made to improve the website.

### 4.1 HTML Structure

The HTML structure was reviewed and corrected.

Incorrect HTML elements and nesting were corrected.

For example, the incorrect `figue` element on the gallery
page was corrected to the proper `figure` element.

The services page was also corrected where unordered
lists and list items were not properly structured.

### 4.2 Accessibility

Alternative text was improved for images.

Labels were added to the contact form fields to make the
form easier to understand and use.

### 4.3 Navigation

Navigation links were reviewed to ensure that all pages
are correctly connected.

The active page is highlighted using CSS.

---

# 5. Part 2 CSS Styling

## 5.1 External Stylesheet

An external stylesheet called `style.css` was created.

All HTML pages are linked to the same stylesheet using:

```html
<link rel="stylesheet" href="css/style.css">
